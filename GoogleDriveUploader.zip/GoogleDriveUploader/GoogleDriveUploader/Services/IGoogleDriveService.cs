﻿using Google.Apis.Drive.v3;

public interface IGoogleDriveService
{
    DriveService GetDriveService();
    string? UploadFile(Stream fileStream, string fileName);
}