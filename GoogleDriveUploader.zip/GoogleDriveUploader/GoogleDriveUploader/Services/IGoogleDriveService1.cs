﻿using Google.Apis.Drive.v3;

public interface IGoogleDriveService1
{
    DriveService GetDriveService();
    string? UploadFile(Stream fileStream, string fileName);
}