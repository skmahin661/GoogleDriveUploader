﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using System;
using System.IO;

public class GoogleDriveService
{
    private const string ApplicationName = "Google Drive File Uploader";
    private readonly string FolderId = "1_tQwydPgtSZn57Ghf_P3A-qxUT26OPK9"; // Replace with your Google Drive folder ID

    /// <summary>
    /// Initializes the Google Drive service.
    /// </summary>
    /// <returns>An authenticated DriveService instance.</returns>
    public DriveService GetDriveService()
    {
        using (var stream = new FileStream("App_Data/fileupdownloader-2160e9382b0c.json", FileMode.Open, FileAccess.Read))
        {
            var credential = GoogleCredential.FromStream(stream)
                .CreateScoped(DriveService.Scope.DriveFile);

            return new DriveService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });
        }
    }

    /// <summary>
    /// Uploads a file to Google Drive with a customer name prepended to the file name.
    /// </summary>
    /// <param name="fileStream">The file stream to upload.</param>
    /// <param name="CustomerName">The customer's name to prepend to the file name.</param>
    /// <param name="fileName">The original file name.</param>
    /// <returns>The ID of the uploaded file, or null if the upload fails.</returns>
    public string? UploadFile(Stream fileStream, string CustomerName, string fileName)
    {
        try
        {
            var service = GetDriveService();

            // Prepend the customer's name to the file name with an underscore
            string newFileName = $"{CustomerName}_{fileName}";

            var fileMetadata = new Google.Apis.Drive.v3.Data.File
            {
                Name = newFileName,
                Parents = new[] { FolderId } // Upload to the specified folder
            };

            var request = service.Files.Create(fileMetadata, fileStream, "application/octet-stream");
            request.Fields = "id";
            request.Upload();

            return request.ResponseBody?.Id;
        }
        catch (Exception ex)
        {
            // Handle or log exceptions as needed
            throw new Exception("An error occurred while uploading the file to Google Drive.", ex);
        }
    }
}
