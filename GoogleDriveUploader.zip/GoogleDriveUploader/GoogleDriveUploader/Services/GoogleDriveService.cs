﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using System.IO;

public class GoogleDriveService
{
    private const string ApplicationName = "Google Drive File Uploader";
    private readonly string FolderId = "1_tQwydPgtSZn57Ghf_P3A-qxUT26OPK9"; // Replace with your Google Drive folder ID

    public DriveService GetDriveService()
    {
        using (var stream = new FileStream("App_Data/fileupdownloader-2160e9382b0c.json", FileMode.Open, FileAccess.Read))
        {
            var credential = GoogleCredential.FromStream(stream)
                .CreateScoped(DriveService.Scope.DriveFile);

            return new DriveService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });
        }
    }

    public string? UploadFile(Stream fileStream, string fileName)
    {
        var service = GetDriveService();

        var fileMetadata = new Google.Apis.Drive.v3.Data.File()
        {
            Name = fileName,
            Parents = new[] { FolderId } // Upload to specific folder
        };

        var request = service.Files.Create(fileMetadata, fileStream, "application/octet-stream");
        request.Fields = "id";
        request.Upload();

        return request.ResponseBody?.Id;
    }

    internal object UploadFile(IDisposable stream, object fileName)
    {
        throw new NotImplementedException();
    }
}
