﻿public class GoogleDriveServiceBase
{
}