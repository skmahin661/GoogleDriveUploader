﻿
namespace GoogleDriveUploader.Controllers
{
    public class HttpPostedFileBase
    {
        public int ContentLength { get; internal set; }
        public IDisposable InputStream { get; internal set; }
        public string FileName { get; internal set; }
    }
}