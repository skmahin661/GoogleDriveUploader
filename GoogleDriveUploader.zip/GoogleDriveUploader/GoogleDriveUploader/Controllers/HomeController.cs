using System.Diagnostics;
using GoogleDriveUploader.Models;
using Microsoft.AspNetCore.Mvc;

namespace GoogleDriveUploader.Controllers
{
    public class HomeController : Controller
{
    private readonly GoogleDriveService _googleDriveService = new GoogleDriveService();

    // Default Index method (don't remove this)
    public ActionResult Index()
    {
        return View();
    }

        // New UploadFile method (add this below the Index method)
        [HttpPost]
        public IActionResult UploadFile(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                using (var stream = file.OpenReadStream())
                {
                    var fileId = _googleDriveService.UploadFile(stream, file.FileName);
                    ViewBag.Message = $"File uploaded successfully! File ID: {fileId}";
                } //gg
            }
            else
            {
                ViewBag.Message = "Please select a file.";
            }

            return View("Index");
        }

    }
}
