using System.Diagnostics;
using GoogleDriveUploader.Models;
using Microsoft.AspNetCore.Mvc;

namespace GoogleDriveUploader.Controllers
{
    public class HomeController : Controller
    {
        private readonly GoogleDriveService _googleDriveService = new GoogleDriveService();

        // Default Index method (don't remove this)
        public IActionResult Index()
        {
            return View();
        }

        // New UploadFile method (updated)
        [HttpPost]
        public IActionResult UploadFile(string CustomerName, IFormFile file)
        {
            if (file != null && file.Length > 0 && !string.IsNullOrEmpty(CustomerName))
            {
                // Extract the original file name
                string originalFileName = Path.GetFileName(file.FileName);

                using (var stream = file.OpenReadStream())
                {
                    // Call the GoogleDriveService method to upload the file
                    var fileId = _googleDriveService.UploadFile(stream, CustomerName, originalFileName);

                    if (!string.IsNullOrEmpty(fileId))
                    {
                        ViewBag.Message = $"File uploaded successfully! File ID: {fileId}";
                    }
                    else
                    {
                        ViewBag.Message = "File upload failed. Please try again.";
                    }
                }
            }
            else
            {
                ViewBag.Message = "Please provide a customer name and select a file.";
            }

            return View("Index");
        }
    }
}
