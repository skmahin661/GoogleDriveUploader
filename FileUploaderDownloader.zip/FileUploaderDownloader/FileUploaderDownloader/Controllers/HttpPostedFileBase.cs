﻿
namespace YourNamespace.Controllers
{
    public class HttpPostedFileBase
    {
        public int ContentLength { get; internal set; }
        public string ContentType { get; internal set; }
        public string? FileName { get; internal set; }
        public IDisposable InputStream { get; internal set; }
    }
}