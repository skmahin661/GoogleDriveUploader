﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using Microsoft.AspNetCore.Mvc;
using YourNamespace.Controllers;

namespace FileUploaderDownloader.Controllers
{
    public class FileUploadController : Controller
    {
        private readonly IWebHostEnvironment _hostingEnvironment;

        public FileUploadController(IWebHostEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }

        public IEnumerable<string> Scopes { get; private set; }
        public string ApplicationName { get; private set; }

        [HttpPost]
        public ActionResult UploadFile(HttpPostedFileBase file)
        {
            if (file == null || file.ContentLength == 0)
            {
                ViewBag.Message = "No file selected.";
                return View("Index");
            }

            try
            {
                // Authenticate user
                UserCredential credential;
                using (FileStream stream = new(
                    Path.Combine(_hostingEnvironment.ContentRootPath, "App_Data", "keys", "fileupdownloader-2160e9382b0c.json"),
                    FileMode.Open,
                    FileAccess.Read))
                {
                    // Replace the line with the error
                    string credPath = Path.Combine(_hostingEnvironment.ContentRootPath, "App_Data", "token.json");
                    credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                        GoogleClientSecrets.Load(stream).Secrets,
                        Scopes,
                        "user",
                        CancellationToken.None,
                        new FileDataStore(credPath, true)).Result;
                }

                // Create Drive API service
                var service = new DriveService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = ApplicationName,
                });

                // Folder ID where the file will be uploaded
                string folderId = "1-sM4CmdnGhPEc9inm5ulfIrhAmMQP6lu "; // Replace with your folder ID

                // File metadata
                var fileMetadata = new Google.Apis.Drive.v3.Data.File()
                {
                    Name = Path.GetFileName(file.FileName),
                    Parents = new[] { folderId } // Set the parent folder
                };

                // Upload file
                FilesResource.CreateMediaUpload request;
                using (var fileStream = file.InputStream)
                {
                    request = service.Files.Create(
                        fileMetadata, (Stream)fileStream, file.ContentType);
                    request.Fields = "id";
                    request.Upload();
                }

                var fileId = request.ResponseBody?.Id;
                ViewBag.Message = $"File uploaded successfully to folder. File ID: {fileId}";
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Error: {ex.Message}";
            }

            return View("Index");
        }
    }
}
