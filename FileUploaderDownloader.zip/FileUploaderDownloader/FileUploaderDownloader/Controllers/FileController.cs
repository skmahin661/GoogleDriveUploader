﻿using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace FileUploaderDownloader.Controllers
{
    public class FileController : Controller
    {
        private readonly string _uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "UploadedFiles");

        public IActionResult Index()
        {
            var files = Directory.GetFiles(_uploadPath);
            ViewBag.Files = files.Select(Path.GetFileName).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Upload(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                string filePath = Path.Combine(_uploadPath, file.FileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                TempData["Message"] = "File uploaded successfully!";
            }
            else
            {
                TempData["Message"] = "No file selected.";
            }

            return RedirectToAction("Index");
        }

        public IActionResult Download(string fileName)
        {
            var filePath = Path.Combine(_uploadPath, fileName);

            if (System.IO.File.Exists(filePath))
            {
                var fileBytes = System.IO.File.ReadAllBytes(filePath);
                return File(fileBytes, "application/octet-stream", fileName);
            }

            TempData["Message"] = "File not found!";
            return RedirectToAction("Index");
        }
    }
}
