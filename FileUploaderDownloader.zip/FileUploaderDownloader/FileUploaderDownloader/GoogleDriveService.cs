﻿using Google.Apis.Drive.v3;
using Google.Apis.Upload;
using System;
using System.IO;
using System.Threading.Tasks;

public class GoogleDriveService
{
    private readonly DriveService _driveService;

    public GoogleDriveService(DriveService driveService)
    {
        _driveService = driveService ?? throw new ArgumentNullException(nameof(driveService)); 
    }

    public async Task<string> UploadFileToGoogleDrive(string filePath, string fileName, string folderId = null)
    {
        var fileMetadata = new Google.Apis.Drive.v3.Data.File
        {
            Name = fileName
        };
        if (!string.IsNullOrEmpty(folderId))
        {
            fileMetadata.Parents = new[] { folderId };
        }

        await using var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
        var request = _driveService.Files.Create(fileMetadata, fileStream, "application/octet-stream");
        request.Fields = "id";

        var progress = await request.UploadAsync();
        if (progress.Status == UploadStatus.Failed)
        {
            throw new Exception($"Google Drive upload failed: {progress.Exception}");
        }

        return request.ResponseBody.Id;
    }
}
